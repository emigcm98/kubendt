#!/bin/bash

GNB_RADIO_IP="${GNB_RADIO_IP:-10.6.0.1}"

# --- Wait for eth1 IP (radio, assigned by CNI when the link is created) ------
echo "[ue] Waiting for IP on eth1 (radio)..."
for i in $(seq 1 120); do
    RADIO_IP=$(ip -4 addr show eth1 2>/dev/null | awk '/inet /{print $2}' | head -1)
    [ -n "$RADIO_IP" ] && break
    sleep 1
done
if [ -z "$RADIO_IP" ]; then
    echo "[ue] ERROR: eth1 has no IP after 2 min" >&2
    exit 1
fi
echo "[ue] Radio IP: $RADIO_IP"

# --- Wait for gNB reachability ------------------------------------------------
# The gNB always responds over the direct link, but we wait up to 5 min
# in case network_conf is still being applied and nr-gnb hasn't started yet.
echo "[ue] Waiting for gNB ($GNB_RADIO_IP) to be reachable..."
for i in $(seq 1 300); do
    if ping -c1 -W1 "$GNB_RADIO_IP" > /dev/null 2>&1; then
        echo "[ue] gNB reachable (attempt $i)"
        break
    fi
    sleep 1
done

envsubst < /mnt/ue/ue.yaml > /tmp/ue.yaml

# --- nr-ue retry loop ---------------------------------------------------------
# nr-ue never exits on registration failure (it retries internally via NAS
# timers). We run it in the background and watch for uesimtun0 to appear,
# which signals a successful PDU session. If it does not appear within 30s
# we kill the process and restart after 10s.
echo "[ue] Starting nr-ue (IMSI: ${MCC}${MNC}${MSISDN}, gNB: $GNB_RADIO_IP)"
while true; do
    nr-ue -c /tmp/ue.yaml &
    NR_PID=$!

    CONNECTED=0
    for i in $(seq 1 15); do
        # If nr-ue died on its own, stop waiting
        if ! kill -0 "$NR_PID" 2>/dev/null; then
            echo "[ue] nr-ue exited unexpectedly"
            break
        fi
        if ip link show uesimtun0 > /dev/null 2>&1; then
            echo "[ue] PDU session established (uesimtun0 is up)"
            CONNECTED=1
            break
        fi
        sleep 2
    done

    if [ "$CONNECTED" -eq 1 ]; then
        ip route replace default dev uesimtun0
        echo "[ue] Default route -> uesimtun0"

        # Stay alive as long as nr-ue is running
        wait "$NR_PID"
        EXIT_CODE=$?
        if [ "$EXIT_CODE" -eq 0 ]; then
            echo "[ue] nr-ue exited cleanly"
            break
        fi
        echo "[ue] nr-ue exited with code $EXIT_CODE, retrying in 10s..."
    else
        echo "[ue] uesimtun0 did not appear within 30s, killing nr-ue and retrying in 10s..."
        kill "$NR_PID" 2>/dev/null
        wait "$NR_PID" 2>/dev/null
    fi

    sleep 10
done
