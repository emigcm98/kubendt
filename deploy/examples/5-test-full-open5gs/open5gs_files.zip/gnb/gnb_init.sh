#!/bin/bash
set -e

# eth2 (radio link to UE) gets its IP from the CNI when the link is created.
# eth1 (VLAN 800, N2/N3) has no IP at startup: it is assigned by kubendt
# via network_conf (replace_ip action). Wait until it appears.

echo "[gnb] Waiting for IP on eth1 (N2/N3) — will block until network_conf is applied..."
while true; do
    N2_IP=$(ip -4 addr show eth1 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -1)
    [ -n "$N2_IP" ] && break
    sleep 2
done
echo "[gnb] eth1 IP acquired: $N2_IP"

RADIO_IP=$(ip -4 addr show eth2 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -1)
if [ -z "$RADIO_IP" ]; then
    echo "[gnb] ERROR: eth2 (radio) has no IP" >&2
    exit 1
fi

export N2_BIND_IP="$N2_IP"
export N3_BIND_IP="$N2_IP"
export N3_ADVERTISE_IP="$N2_IP"
export RADIO_BIND_IP="$RADIO_IP"

echo "[gnb] eth1 N2/N3: $N2_IP  |  eth2 Radio: $RADIO_IP  |  AMF: ${AMF_IP}"

envsubst < /mnt/gnb/gnb.yaml > /tmp/gnb.yaml
exec nr-gnb -c /tmp/gnb.yaml
